
package parcial2;

public abstract class VehiculoMovil {
    
    public abstract void desplazar();
    
    public abstract void subirVelocidad();
    
    public abstract void detenerse();
    
}
