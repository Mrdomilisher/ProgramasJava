package animalitos;

public class Main {

    public static void main(String[] args) {
//        Animal a1= new Perro();          //Upcasting
//        Mamifero m1 = new Perro();       //Upcasting
//        Perro p1 = new Perro();
//        Pato pa1= new Pato();
//        Leon l1 = new Leon();
//        sonidoAnimal(p1);
//        sonidoAnimal(pa1);
//        sonidoAnimal(l1);

        Animal a = new Perro(); //Perro es un Animal, es un objeto perro
        Mamifero m = (Mamifero)a; //Perro es un mamifero, downcasting, convierte perro en mamifero. El perro es un mamifero entonces sí se puede, a es un objeto perro
    }

    public static void sonidoAnimal(Animal a) {
        a.sonido();
    }

}
