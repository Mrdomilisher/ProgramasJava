
package animalitos;

public class Ave extends Animal{

    @Override
    public void sonido() {
        System.out.println("Sonido ave");
    }
    
    
}
