
package animalitos;

public class Perro extends Mamifero{

    @Override
    public void sonido() {
        System.out.println("Sonido Perro");
    }
    
    
}
