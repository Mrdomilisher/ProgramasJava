
package animalitos;

public class Mamifero extends Animal{

    @Override
    public void sonido() {
        System.out.println("Sonido Mamifero");
    }
    
}
