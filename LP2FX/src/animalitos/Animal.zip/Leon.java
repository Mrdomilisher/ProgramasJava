
package animalitos;

public class Leon extends Mamifero{

    @Override
    public void sonido() {
        System.out.println("Sonido Leon");
    }
    
    
    
}
