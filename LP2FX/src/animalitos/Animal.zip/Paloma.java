
package animalitos;

public class Paloma extends Ave{

    @Override
    public void sonido() {
        System.out.println("Sonido Paloma");
    }
    
    
    
}
