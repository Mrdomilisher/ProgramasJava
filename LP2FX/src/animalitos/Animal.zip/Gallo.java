
package animalitos;

public class Gallo extends Ave{

    @Override
    public void sonido() {
        System.out.println("Sonido gallo");
    }
    
    
}
