
package animalitos;

public abstract class Animal {
    
    public abstract void sonido();
    
}
